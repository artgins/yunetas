libargp-mingw
------

A quick and dirty port of argp for MinGW applications. Pulled from
http://emfisis.physics.uiowa.edu/Software/C/libargp and adapted for
CMake.

The license is LGPL.

### Donate
- XMR: `83vzgeeKebLh6pj2YtBqn7PqxY47CkyzmLzUhmHfhTCQdj9Mfad4FUF12Yu9ry5uUh5JASTcXg5Fwji5ibjUngw9LomnH6Z`
- ETH: `0x1bdA7dB6484802DFf4945edc52363B4A8FAcb470`
- ETC: `0x4a368bb4cd854f650169ce207268c303ffecafb2`
