Assets
======

The `h5bp` directory contains a web structure built with html5-boilerplate_v6.0.1.

The `logo` directory has the genera_apple_icons.sh script to generate all needed icons for h5bp template.
The original logo must be written in svg format.
You need install inkscape.
