#!/bin/sh -e

autoreconf -vi
