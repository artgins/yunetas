import './force-graph.css';

export { default } from "./force-graph";