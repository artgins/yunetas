#ifndef CSPTR_CONFIG_H_IN_
# define CSPTR_CONFIG_H_IN_

 #define SMALLOC_FIXED_ALLOCATOR 1
/* #undef CSPTR_NO_SENTINEL */

# define CSPTR_PACKAGE "csptr"
# define CSPTR_VERSION "2.0.5-7"

#endif /* !CSPTR_CONFIG_H_IN_ */
