#include <stdlib.h>

char *program_invocation_name = NULL;
